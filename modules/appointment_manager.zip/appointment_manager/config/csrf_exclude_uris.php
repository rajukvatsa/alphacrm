<?php

defined('BASEPATH') or exit('No direct script access allowed');

return [ 
		'appointment_manager/appointment_manager_client.*+'
	  ];