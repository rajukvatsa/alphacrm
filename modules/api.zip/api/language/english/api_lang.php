<?php

# Version 1.0.0
$lang['api']        = 'API';
$lang['api_management']        = 'API Management';
$lang['api_guide']        = 'API Manual';
$lang['new_user_api']		= 'New User';
$lang['edit_user_api']		= 'Edit User';
$lang['user_api']		= 'User';
$lang['name_api']		= 'Name';
$lang['password_api']		= 'Password';
$lang['repeat_passwork_api']	= 'Repeat Passwork';
$lang['token_api']		= 'Token';
$lang['expiration_date']		= 'Expiration Date';